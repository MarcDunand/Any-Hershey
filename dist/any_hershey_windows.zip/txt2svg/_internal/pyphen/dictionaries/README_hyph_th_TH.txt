Thai hyphenation patterns for LibreOffice.org
Version 1.0 (2022-04-30)

License:  LPPL 1.3+

Origin:
  These Thai hyphenation patterns are based on word list from LibThai project,
  manually hyphenated to be processed with patgen, plus additional processing,
  by tex-hyphen project, and then converted for libhyphen using its
  substrings.pl script.

Author:
  Theppitak Karoonboonyanan <theppitak@gmail.com>
