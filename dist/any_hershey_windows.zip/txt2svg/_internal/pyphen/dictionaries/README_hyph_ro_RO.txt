This is Romanian OpenOffice.org dictionary extension, implementing the orthography
after 1993 (â/sunt). The package contains hyphenation and spelling dictionaries, and
a thesaurus. The extension was build by Lucian Constantin (http://rospell.sourceforge.net).

Authors and licenses:

Author:  Adrian Stoica (office@cuvinte.ro)
License: GNU GPL, please see COPYING.GPL for more details

Support:
   Please direct all your questions to http://groups.google.com/group/rospell mailing list.
