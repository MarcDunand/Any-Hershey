% The hyp_sq_AL.dic file contains hyphenation patterns for the Albanian language, created semi-automatically
--------------------------
% Author: Isah Bllaca <isah (dot) bllaca (at) gmail (dot) com>
% Version 1 (04.01.2021)
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.
